package com.example.utkarshsharma.onlinecabservice;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class DriverDashboard extends AppCompatActivity {
    private Button call;
    private Button notes;
    private Button attendance;
    private Button chat;
    private Button profile;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_dashboard);
        call=(Button)findViewById(R.id.call);
        notes=(Button)findViewById(R.id.notes);
        attendance=(Button)findViewById(R.id.attendance);
        chat=(Button)findViewById(R.id.chat);
        profile=(Button)findViewById(R.id.profile);

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(DriverDashboard.this,DriverMapActivity.class);
                startActivity(intent);
            }
        });
        notes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(DriverDashboard.this,UploadMain.class);
                startActivity(intent);
            }
        });
        attendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(DriverDashboard.this,UploadPic.class);
                startActivity(intent);
            }
        });

    }
}
